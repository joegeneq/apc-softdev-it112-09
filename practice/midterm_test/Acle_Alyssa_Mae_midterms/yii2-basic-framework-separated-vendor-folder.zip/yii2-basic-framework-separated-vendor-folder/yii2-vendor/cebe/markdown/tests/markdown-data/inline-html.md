this is <span class="name">inline **html**</span> trailing

&copy; AT&T

<del>this is deleted</del> this is not
new text on new line

<s>this is deleted</s> this is not
new text on new line

this line ends with <

this line ends with &
