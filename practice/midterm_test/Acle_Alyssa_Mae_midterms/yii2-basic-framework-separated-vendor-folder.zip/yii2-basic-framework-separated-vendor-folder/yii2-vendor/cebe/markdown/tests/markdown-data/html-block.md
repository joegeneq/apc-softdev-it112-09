paragraph 1 is here

<table>
	<tr>
		<td>a</td>
		<td>b</td>
	</tr>
	<tr>
		<td>c</td>
		<td>d</td>
	</tr>
</table>

more markdown here

< this is not an html tag

<thisisnotanhtmltag

<span class="test">some inline **md**</span>

<span>some inline **md**</span>

self-closing on block level:

<p>this is a paragraph</p>
<hr style="clear: both;" />