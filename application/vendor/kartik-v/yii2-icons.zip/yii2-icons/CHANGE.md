version 1.4.0
=============
**Date:** 04-Feb-2015

- (enh #13): Add Socicon Icons
- (enh #15): Add [Octicons](https://octicons.github.com/)

version 1.3.0
=============
**Date:** 18-Dec-2014

- (enh #10): Add `showStack` method for displaying stacked icons like in FA

version 1.2.0
=============
**Date:** 08-Dec-2014

- (enh #6): Create a new JUI asset for core yii\jui package change.
- (enh #7): Update typicons to latest version.
- (enh #8): Update elusive icons to latest version.
- (enh #9): Update WHHG icons to latest version.

version 1.1.0
=============
**Date:** 10-Nov-2014

- Set dependency on Krajee base components
- Set release to stable

version 1.0.0
=============

*Date:* 01-Mar-2014

- Initial release
- PSR4 alias change
